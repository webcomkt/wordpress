<div class="fl-page-footer">
	<div class="fl-page-footer-container <?php FLLayout::container_class(); ?>">
		<div class="fl-page-footer-row <?php FLLayout::row_class(); ?>">
			<?php FLTheme::footer_col1(); ?>
			<?php FLTheme::footer_col2(); ?>
		</div>
	</div>
</div><!-- .fl-page-footer -->
