<header class="fl-archive-header" role="banner">
	<h1 class="fl-archive-title"><?php echo $page_title; ?></h1>
</header>
