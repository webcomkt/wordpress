<?php

if ( class_exists( 'FLUpdater' ) ) {
	FLUpdater::add_product( array(
		'name'      => 'Beaver Themer',
		'version'   => '1.1',
		'slug'      => 'bb-theme-builder',
		'type'      => 'plugin',
	) );
}
