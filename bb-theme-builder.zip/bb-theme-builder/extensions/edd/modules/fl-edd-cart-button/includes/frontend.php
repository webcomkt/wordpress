<?php

echo FLPageDataEDD::get_add_to_cart_button();
