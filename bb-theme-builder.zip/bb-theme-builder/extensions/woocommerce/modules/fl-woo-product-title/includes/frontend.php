<?php

echo FLPageDataWooCommerce::get_product_title();
