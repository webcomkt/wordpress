<?php

echo FLPageDataWooCommerce::get_related_products();
