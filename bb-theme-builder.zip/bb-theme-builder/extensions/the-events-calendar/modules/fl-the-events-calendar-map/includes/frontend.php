<?php

tribe_get_template_part( 'modules/meta/map' );
