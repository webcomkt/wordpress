<?php

tribe_single_related_events();
