[tribe_event_countdown id="<?php the_ID(); ?>"<?php if ( $settings->show_seconds ) : ?> show_seconds="yes"<?php endif; ?>]
