jQuery(document).ready(function($){
  
  jQuery('body').on('click','.bt-row-overlay .fl-block-overlay-header',function(){
    
    var post = jQuery(this).closest('.fl-builder-content').attr('data-post-id');
    url = "/wp-admin/post.php?post="+post+"&action=edit&launch_builder";
    
    window.open(url,'_blank');
    
  });
  
  var bt_overlay = 	"<div class='bt-row-overlay fl-block-overlay'><div class='fl-block-overlay-header'><div class='fl-block-overlay-actions'><i class='fl-block-settings fas fa-wrench fl-tip' title='Edit Template'></i><span></span><div class='fl-clear'></div></div></div>";
  
  jQuery('body').on('mouseenter','.fl-builder-content[data-type]:not(.fl-builder-content-editing)',function(){
    if(jQuery('body').hasClass('fl-builder-edit'))
    {
      //get post id
      var bt_datatype = jQuery(this).attr('data-type').toUpperCase();
      jQuery('.bt-row-overlay').remove();
      jQuery(this).addClass('fl-block-overlay-active').addClass('bt-block-overlay-active').append(bt_overlay);
      jQuery(this).find('.bt-row-overlay .fl-block-overlay-actions span').text(bt_datatype)
    }
  });
  jQuery('body').on('mouseleave','.fl-builder-content[data-type]',function(){    
    jQuery(this).removeClass('fl-block-overlay-active').removeClass('bt-block-overlay-active').find('.bt-row-overlay').remove();
  });
});