jQuery(document).ready(function(){

  FLBuilder.addHook('didShowLightbox', bt_scss_editor_mods);


	jQuery(document).on("click", "#scss-vars", function(){
		jQuery("#scss-vars-list").slideToggle();
	});

	jQuery(document).on("focus", "#fl-field-scss_input textarea", function(){
		if(!jQuery(this).hasClass('bt_cleaned_up'))
		{
			var editor = ace.edit(jQuery("#fl-field-scss_input .ace_editor")[0]);
			editor.getSession().setUseWorker(false);
			jQuery(this).addClass('bt_cleaned_up')
		}

	});



	jQuery(document).on("blur", "#fl-field-scss_input textarea", function(){
	  	
		var editor = ace.edit(jQuery("#fl-field-scss_input .ace_editor")[0]);
		var scss = editor.getValue();

		var scss_request = {
			action: "render_scss",
			scss: scss
		};

		jQuery.post(ajaxurl,scss_request,function(data){
			//jQuery('#fl-field-scss_output textarea').text(data);
			
			var css_out_editor = ace.edit(jQuery("#fl-field-scss_output .ace_editor")[0]);
			css_out_editor.setValue(data);

		});

	});



});


function bt_scss_editor_mods(){
	if(jQuery("#fl-field-scss_input .ace_editor").length)
	{
		alert('bem');
		editor = ace.edit(jQuery("#fl-field-scss_output .ace_editor")[0]);
		editor.getSession().setUseWorker(false);
	}
}