<?php


if(! class_exists ( 'Bt_Sticky_Column') && class_exists('FLBuilder'))
{
  class Bt_Sticky_Column{

    function __construct(){

      //filters
      add_filter( 'fl_builder_register_settings_form' , array($this,'add_sticky_settings'), 20 , 2 );
      add_filter( 'fl_builder_column_attributes' , array( $this,'add_column_attributes'), 10, 2);
      add_filter( 'fl_builder_row_attributes' , array( $this,'add_column_attributes'), 10, 2);
      add_filter( 'wp_enqueue_scripts' , array($this,'bt_sticky_column_scripts'), 20 , 2 );
      
    }

    function add_sticky_settings( $form, $slug ) {

      
      if ( 'col' === $slug || 'row' === $slug ) {
        if($slug == 'col')
          $label = 'Sticky Column';
        if($slug == 'row')
          $label = 'Sticky Row';

        
        $form[ 'tabs' ][ 'advanced' ][ 'sections' ][ 'visibility' ][ 'fields' ][ 'sticky' ] = [
          'type'    => 'select',
          'label'   => $label,
          'default' => 'false',
          'options'       => array(
            'false'      => __( 'Never', 'fl-builder' ),
            'true'      => __( 'All Screen Sizes', 'fl-builder' ),
            'large'      => __( 'Large Only', 'fl-builder' ),
            'large-med'      => __( 'Large + Medium', 'fl-builder' ),
            'med'      => __( 'Medium Only', 'fl-builder' ),
            'med-small'      => __( 'Small + Medium', 'fl-builder' ),
            'small'      => __( 'Small Only', 'fl-builder' ),
            
          ),
          'toggle'        => array(
            'true'      => array(
                'fields'  => array( 'stickyOffset' ,'stickPosition')
             ),
            'large'      => array(
                'fields'  => array( 'stickyOffset' ,'stickPosition')
             ),
            'large-med'      => array(
                'fields'  => array( 'stickyOffset' ,'stickPosition')
             ),
            'med'      => array(
                'fields'  => array( 'stickyOffset' ,'stickPosition')
             ),
            'med-small'      => array(
                'fields'  => array( 'stickyOffset' ,'stickPosition')
             ),
            'small'      => array(
                'fields'  => array( 'stickyOffset' ,'stickPosition')
             ),
            'false'   => array()
          )
        ];
        $form[ 'tabs' ][ 'advanced' ][ 'sections' ][ 'visibility' ][ 'fields' ][ 'stickPosition' ] = [
          'type'    => 'select',
          'label'   => 'Sticky Position',
          'default' => 'top',
          'options'       => array(
            'top'      => __( 'Top', 'fl-builder' ),
            'bottom'      => __( 'Bottom', 'fl-builder' ),           
          ),
        ];




        $form[ 'tabs' ][ 'advanced' ][ 'sections' ][ 'visibility' ][ 'fields' ][ 'stickyOffset' ] = [
          'type'        => 'unit',
          'label'       => 'Sticky item offset from the top/bottom of window',
          'default'     => '50',
          'description' => 'px',
        ];
      }

      /**
       * Now we pass back the form to the filter
       */
      return $form;
    }


    function add_column_attributes( $attrs, $column ) {
      // if there is a data sticky attribute set, then add the atts to the page
      if ( isset( $column->settings->sticky )  &&  'false' !== $column->settings->sticky)  {
        $attrs[ 'bt-sticky' ] = $column->settings->sticky;
        $attrs[ 'bt-sticky-offset' ] = $column->settings->stickyOffset;
        $attrs[ 'bt-sticky-position' ] = $column->settings->stickPosition;
      }
      return $attrs;
    }

    //enqueue js
    function bt_sticky_column_scripts() {
        wp_enqueue_script( 'sticky_script', plugin_dir_url( __FILE__ ) . 'js/sticky-column.js', array('jquery') );
        wp_enqueue_style( 'sticky_style', plugin_dir_url( __FILE__ ) . 'css/sticky-column.css' );
    }
  }
  $btsc = new Bt_Sticky_Column();
}

