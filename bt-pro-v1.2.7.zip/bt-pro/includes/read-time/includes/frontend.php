<?php

/**
 * This file should be used to render each module instance.
 * You have access to two variables in this file: 
 * 
 * $module An instance of your module class.
 * $settings The module's settings.
 *
 * Example: 
 */

?>

<div class="sp-read-time" style="font-weight:<?php echo $settings->read_time_font['weight'];?>; font-family:<?php echo $settings->read_time_font['family'];?>; color:#<?php echo $settings->read_time_color;?>; font-size:<?php echo $settings->read_time_font_size;?>px;">

  <span class="sp-read-time-pre"><?php echo $settings->read_time_pre; ?></span>
  <span class="sp-read-time-time"></span>
  <span class="sp-read-time-post"><?php echo $settings->read_time_post; ?></span>
    
  <script>
  jQuery(document).ready(function(){
    	jQuery('<?php echo $settings->read_time; ?>').readingTime({
        readingTimeAsNumber: true,
        readingTimeTarget: jQuery('.sp-read-time-time'),
  	});
  });
  </script>
</div>