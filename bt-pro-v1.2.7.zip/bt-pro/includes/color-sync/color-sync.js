jQuery(document).ready(function(){
    
  jQuery('.wp-picker-container').iris({
    mode: 'hsl',
    palettes: bt_bb_color_presets,
  });
    
  // easter egg! refresh customizer by doubleclicking next to save and publish
  jQuery( '#customize-header-actions, .wp-full-overlay-sidebar-content' ).on( 'dblclick', function() {
      wp.customize.previewer.refresh();
  } );
});
// look out for astra - class "ast-color-picker-alpha"