
/* called on builder end


sends postid to WP, responds with beaver builder draft meta

loops through draft meta to find changes

//check inside arrays

create options to update. with json again

*/


jQuery(document).ready(function(){
    
  // new button handler and settings getter
  
  jQuery('body').on('click','#set-module-default',function(){

    FLBuilder.showAjaxLoader();

      // get all new settings
    var nodeId    = jQuery( '.fl-builder-module-settings' ).data( 'node' ),
        form      = jQuery( '.fl-builder-module-settings[data-node=' + nodeId + ']' ),
        type      = jQuery( '.fl-builder-module-settings' ).data( 'type' ),
        settings  = FLBuilder._getSettings( form );

    var modSet = {
      "type" : type,
      "settings" : settings
    }

    // send em to the backend
    var moduleData = {
      'action': 'default_module',
      'settings': modSet
    };

    jQuery.post(ajaxurl, moduleData, function(response) {
        alert(response);
        FLBuilderSettingsConfig.defaults.modules[type] = settings;
        FLBuilder.hideAjaxLoader();
    });

    // refresh setting defaults
  
  }); // end on click

  // pretty sure its all dead zone after here

  jQuery('body').on('click','.fl-builder-update-existing-button',function(){
    btGetChanges();
  });
  
  jQuery('body').on('click','.changes-overlay',function(){
    jQuery('.changes-overlay, .changes-modal').hide();
  });
  
  jQuery('body').on('click','.changes-container button',function(){
    console.log( bt_update_all_modules(jQuery(this).attr('data.module'), jQuery(this).attr('data.key'), jQuery(this).attr('data.childkey'),  jQuery(this).attr('data.value'),this));
    //jQuery(this).text(updated_modules + " modules updated");
  });  
})


function btGetChanges(){
  
  jQuery('.fl-builder-settings-save').click(); // save current settings
  
  //todo wait until settings status is saved, then 
  
  var data = {
        'action': 'bt_changes',
        'pid': FLBuilderConfig.postId
      };
  
  jQuery.post(ajaxurl, data, function(response) {
    
    jQuery('.changes-overlay, .changes-modal').show();

    resp = JSON.parse(response);
    //alert(response);
    
    //add in the modal
    if (!jQuery(".changes-modal")[0]){
      jQuery('body').append("<div class='changes-overlay'></div><div class='changes-modal'><h3>Update All</h3><div class='changes-container'>Changes container</div></div>");
    }
    
    jQuery('.changes-container').html("<h4>Detected changes to: "+ resp.type +"</h4>");
    
    jQuery.each(resp.changes, function(index,value){
      
      var keyText = value.key;
      
      if(value.childkey)
        keyText = keyText + " -> " + value.childkey;
      
      jQuery('.changes-container').append("<p>Setting: " + keyText + " Old Value: " + value.existingValue + " | New Value: " + value.newValue + "<button data.module='"+resp.type+"' data.childkey='"+value.childkey+"' data.key='"+value.key+"' data.value='"+value.newValue+"'>Update "+keyText +"</button></p>");
      
      
    });
    
    if(resp.changes.length > 1)
    {
      //todo update all
      //jQuery('.changes-container').append("<p>Update All <button>Update All</button></p>");
    }
    
    if(resp.changes.length == 0)
    {
      //todo update all
      jQuery('.changes-container').append("<p>No changes found</p>");
    }
    
  });
}





// update functions
function bt_update_all_modules(module = "", key = "", childkey = "", value = "",that)
{
  var data = {
    'action': 'bt_update_module',
    'module'  : module, 	
    'key'  : key, 	
    'childkey'  : childkey, 	
    'value'  : value, 	
  };
  FLBuilder.showAjaxLoader()
  jQuery.ajax({
    type: 'POST',
    url: ajaxurl,
    data: data,
    success: function(response){
      jQuery(that).text(response + " modules updated");
      FLBuilder.hideAjaxLoader();
      FLBuilder._updateLayout();
    },
  });
}
  



