<#

var field = data.field,
    name = data.name,
    value = data.value;
#>
<input type="text" class="pp-field-css-class text" value="{{value}}" style="width: 100%;" readonly="readonly" onclick="this.select()" />
