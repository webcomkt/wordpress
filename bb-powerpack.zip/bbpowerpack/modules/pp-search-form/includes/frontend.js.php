;(function($) {
	
	new PPSearchForm({
		id: '<?php echo $id; ?>',
	});

})(jQuery);