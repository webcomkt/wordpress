<div class="pp-rf-field-static-text">
	<?php echo do_shortcode( wpautop( $field->static_text ) ); ?>
</div>