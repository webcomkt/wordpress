(function($) {
    $('.fl-node-<?php echo $id; ?> .pp-notification-icon').css('height', $('.fl-node-<?php echo $id; ?> .pp-notification-wrapper').height() + 'px')
})(jQuery);
