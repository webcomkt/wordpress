<g class="fl-shape">
<?php
for ( $i = 0; $i <= 64; $i++ ) {
	$offset = $i * 50;
	?>
<polygon points="<?php echo $offset + 25; ?>,34 <?php echo $offset; ?>,0 <?php echo $offset + 50; ?>,0"></polygon>
<?php } ?>
</g>
