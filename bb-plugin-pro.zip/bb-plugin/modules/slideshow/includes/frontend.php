<?php // Display slideshow ?>
<div class="fl-slideshow-container"></div>
