(function($) {

	$(function() {

		new FLBuilderLoginForm({
			id: '<?php echo $id; ?>'
		});
	});

})(jQuery);
