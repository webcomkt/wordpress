(function($) {

	$(function() {

		new FLBuilderTabs({
			id: '<?php echo $id; ?>'
		});
	});

})(jQuery);
