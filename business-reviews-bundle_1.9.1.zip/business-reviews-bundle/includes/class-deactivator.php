<?php

namespace WP_Business_Reviews_Bundle\Includes;

class Deactivator {

    public function deactivate() {
        //TODO
    }

}
